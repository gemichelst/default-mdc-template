<?php
#################################################################
# configuration file for myshoe database 						#
#################################################################

// SITE
$site_title = "MySHOES Collection Manager";
$site_version = "v0.1";
$site_author = "geMichelst";
$site_author_website = "http://www.gemichelst.de";


// MYSQL
$mysql_host = "localhost";
$mysql_db = "ftnhfhqh_myshoes";
$mysql_user = "myshoes";
$mysql_pass = "dWeAPhxDVycov62O";



?>